# ARQUIVO: artifacts/pista-secreta/src/App.tsx
# ALTERAÇÃO: registrar a rota /investigacao com carregamento sob demanda.
# É a única modificação em arquivo existente.

## 1) Adicionar no topo (junto dos imports de react)

import { lazy, Suspense } from "react";

const InvestigacaoPage = lazy(() => import("@/investigacao/InvestigacaoPage"));

## 2) Substituir a função Router() existente

function Router() {
  const investigacao = (
    <Suspense fallback={<div style={{ minHeight: "100dvh", background: "#060409" }} />}>
      <InvestigacaoPage />
    </Suspense>
  );

  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/investigacao">{investigacao}</Route>
      <Route path="/investigacao/:slug">{investigacao}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

## Observações
- Nenhuma dependência nova.
- Nada muda em index.css, vite.config.ts, .replit ou artifact.toml.
- O rewrite /* -> /index.html do artifact.toml já cobre o deep link em produção.
