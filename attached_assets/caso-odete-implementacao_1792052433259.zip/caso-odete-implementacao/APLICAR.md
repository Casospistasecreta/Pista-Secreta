# Caso Dona Odete — como aplicar no projeto (Replit / GitHub)

Rota nova: `/investigacao/caso-odete` · A base `/investigacao` (caso demo) e o `caso-02` não foram alterados em conteúdo.

## Opção A — copiar os arquivos (mais simples)
1. Descompacte este ZIP.
2. Copie as pastas `artifacts/` por cima da raiz do projeto (as pastas têm o mesmo caminho do repositório).
   Isso cria os arquivos novos e substitui os 10 arquivos compartilhados alterados.
3. Rode `pnpm --filter @workspace/pista-secreta run typecheck` e publique.

## Opção B — aplicar o patch + copiar as imagens
1. `git apply --check codigo.patch && git apply codigo.patch` (somente código).
2. Copie `artifacts/pista-secreta/public/investigacao/caso-odete/` (imagens, WebP) para o mesmo caminho.

## Arquivos
Novos: `cases/caso-odete/*` (10 arquivos), `components/FinalAnswerScreen.tsx`, `state/useFinalAnswer.ts`, `public/investigacao/caso-odete/*` (79 imagens).
Alterados (compatíveis com os casos existentes): `types.ts`, `cases/registry.ts`, `LockScreen.tsx`, `HomeScreen.tsx`, `MessagesApp.tsx`, `NotesApp.tsx`, `MatchesApp.tsx`, `SocialApp.tsx`, `BankApp.tsx`, `CaseFileApp.tsx`.

## Códigos do caso
Tela de bloqueio 0000 · conversa arquivada do Afonso 6969 · nota "Um Tico-Tico Azul" 8613 · transação trancada (Bora Bora) PIN 1987.
