import { useEffect, useState } from "react";
import { Delete, Fingerprint } from "lucide-react";
import { useDevice } from "../state/DeviceProvider";
import { useDeviceClock } from "./StatusBar";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"];

export function LockScreen() {
  const { caseData, unlockDevice } = useDevice();
  const time = useDeviceClock();
  const [code, setCode] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    if (code.length < 4) return;
    const ok = unlockDevice(code);
    if (!ok) {
      setError(true);
      window.setTimeout(() => {
        setError(false);
        setCode("");
      }, 460);
    }
  }, [code, unlockDevice]);

  function press(key: string) {
    if (error) return;
    if (key === "del") {
      setCode((prev) => prev.slice(0, -1));
      return;
    }
    if (key === "") return;
    setCode((prev) => (prev.length >= 4 ? prev : prev + key));
  }

  return (
    <div className="inv-anim-fade relative flex h-full flex-col">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(90% 55% at 50% 0%, rgba(123,63,228,0.28), transparent 65%), radial-gradient(70% 40% at 50% 100%, rgba(255,250,205,0.06), transparent 70%)",
        }}
      />

      <div className="relative flex flex-1 flex-col items-center justify-center px-8 pb-2 pt-6">
        <p className="inv-mono text-[10px] uppercase tracking-[0.3em] text-[var(--inv-dim)]">
          {caseData.device.dateLabel}
        </p>
        <p className="inv-display mt-1 text-[68px] leading-none tracking-tight">{time}</p>
        <p className="mt-6 text-[13px] uppercase tracking-[0.22em] text-[var(--inv-chiffon)]/80">
          {caseData.victim.name}
        </p>
        <p className="inv-mono mt-1 text-[10px] uppercase tracking-[0.18em] text-[var(--inv-dim-2)]">
          Dispositivo bloqueado
        </p>
      </div>

      <div className="relative px-8 pb-8">
        <div className={`mb-6 flex justify-center gap-4 ${error ? "inv-anim-shake" : ""}`}>
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className="h-3 w-3 rounded-full border transition-all duration-200"
              style={{
                borderColor: error ? "var(--inv-danger)" : "var(--inv-line-strong)",
                background:
                  code.length > i
                    ? error
                      ? "var(--inv-danger)"
                      : "var(--inv-chiffon)"
                    : "transparent",
              }}
            />
          ))}
        </div>

        <div className="mx-auto grid max-w-[260px] grid-cols-3 gap-x-5 gap-y-3">
          {KEYS.map((key, index) => {
            if (key === "") return <span key={`empty-${index}`} />;
            if (key === "del") {
              return (
                <button
                  key="del"
                  type="button"
                  onClick={() => press("del")}
                  className="inv-press flex h-[62px] items-center justify-center text-[var(--inv-dim)]"
                  aria-label="Apagar"
                >
                  <Delete size={20} />
                </button>
              );
            }
            return (
              <button
                key={key}
                type="button"
                onClick={() => press(key)}
                className="inv-press flex h-[62px] w-[62px] items-center justify-center justify-self-center rounded-full border border-[var(--inv-line)] bg-white/[0.04] text-xl font-light backdrop-blur-sm hover:bg-white/[0.08]"
              >
                {key}
              </button>
            );
          })}
        </div>

        <div className="mt-7 flex flex-col items-center gap-2 text-[var(--inv-dim-2)]">
          <Fingerprint size={18} className="opacity-50" />
          <p className="inv-mono text-[10px] uppercase tracking-[0.18em]">
            Senha recuperada pela perícia: {caseData.device.passcode}
          </p>
        </div>
      </div>
    </div>
  );
}
