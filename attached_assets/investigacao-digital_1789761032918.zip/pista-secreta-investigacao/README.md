# Investigação Digital — módulo base (Pista Secreta)

Motor + estrutura visual da experiência `/investigacao`. Sem narrativa, sem pistas
definitivas: apenas a fundação reutilizável, com conteúdo placeholder descartável.

Stack detectada no repositório e respeitada aqui: **React 19 + Vite 7 + TypeScript +
wouter + Tailwind v4 + lucide-react**, dentro de `artifacts/pista-secreta`.
Nenhuma dependência nova.

---

## 1. Instalação (2 passos)

### Passo 1 — copiar a pasta

Copie `artifacts/pista-secreta/src/investigacao/` deste pacote para o mesmo caminho
no seu projeto. É uma pasta nova; não sobrescreve nada.

### Passo 2 — registrar a rota

**ARQUIVO:** `artifacts/pista-secreta/src/App.tsx`
**ALTERAÇÃO:** importar a página sob demanda e adicionar duas rotas. É a única
modificação em arquivo existente de todo o módulo.

No topo do arquivo, junto dos imports de react:

```tsx
import { lazy, Suspense } from "react";

const InvestigacaoPage = lazy(() => import("@/investigacao/InvestigacaoPage"));
```

E substitua a função `Router()` existente por:

```tsx
function Router() {
  const investigacao = (
    <Suspense fallback={<div style={{ minHeight: "100dvh", background: "#060409" }} />}>
      <InvestigacaoPage />
    </Suspense>
  );

  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/investigacao">{investigacao}</Route>
      <Route path="/investigacao/:slug">{investigacao}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}
```

O `lazy` garante que o bundle da investigação só seja baixado quando alguém abrir a
rota — a landing page continua com o mesmo peso de antes.

---

## 2. Executar e testar

Desenvolvimento (Replit ou local):

```bash
pnpm --filter @workspace/pista-secreta run dev
```

Abra `/investigacao` (caso padrão) ou `/investigacao/demo`.

Verificações:

```bash
pnpm run typecheck   # deve passar limpo
pnpm run build       # deve buildar normalmente
```

**Produção no Replit:** nada a configurar. O `artifact.toml` já tem o rewrite
`/* → /index.html`, então o deep link `/investigacao` funciona no deploy.

Roteiro rápido de teste manual:

| Passo | Esperado |
|---|---|
| Abrir `/investigacao` | Tela de bloqueio com hora, data e nome da vítima |
| Digitar `0000` | Desbloqueia e revela a home |
| Tocar em qualquer app | Abre interface própria, com transição |
| Botão voltar (tela, navegador ou Esc) | Volta uma tela por vez |
| Marcar uma evidência | Contador na doca "Meu caso" aumenta |
| Mensagens › Arquivadas | Pede senha `1234` |
| Fotos › Álbum oculto | Pede senha `2020` |
| Notas › nota protegida | Pede senha `7777` |
| Recarregar a página | Evidências e desbloqueios permanecem |
| Voltar para `/` | Landing intacta, scroll normal restaurado |

---

## 3. Arquitetura

```
src/investigacao/
├── InvestigacaoPage.tsx     entrada da rota, integra voltar do navegador/Esc
├── index.ts                 exports públicos do módulo
├── types.ts                 contrato de dados (motor ↔ conteúdo)
├── investigacao.css         tokens e animações, escopados em .inv-root
├── cases/
│   ├── registry.ts          mapa slug → caso
│   └── caso-demo.ts         ÚNICO arquivo com conteúdo (placeholder)
├── state/
│   └── DeviceProvider.tsx   pilha de navegação, bloqueio, evidências, desbloqueios
├── components/
│   ├── DeviceFrame.tsx      aparelho (tela cheia no celular, moldura no desktop)
│   ├── StatusBar.tsx        hora, sinal, bateria
│   ├── LockScreen.tsx       bloqueio + teclado numérico
│   ├── HomeScreen.tsx       grade de apps + doca
│   ├── AppShell.tsx         moldura comum: voltar, cabeçalho, área rolável
│   ├── Media.tsx            foto/avatar procedurais + player de áudio simulado
│   ├── EvidenceToggle.tsx   "marcar como evidência"
│   └── PasscodePrompt.tsx   conteúdo desbloqueável
└── apps/
    ├── registry.ts          metadados: nome, ícone, cor de acento, componente
    ├── MessagesApp.tsx      lista de conversas, thread, mídia, áudio, apagadas
    ├── SocialApp.tsx        PicLike: feed, carrossel, comentários, perfis
    ├── MatchesApp.tsx       grade de matches, perfil, conversa
    ├── GalleryApp.tsx       galeria por data, visualizador, informações da foto
    ├── LocationApp.tsx      linha do tempo + mapa estilizado (sem provedor externo)
    ├── BankApp.tsx          NOVA: saldo, extrato, detalhe da transação
    ├── NotesApp.tsx         notas, listas, anexos, notas protegidas
    └── CaseFileApp.tsx      "Meu caso": dossiê de evidências
```

Princípio: **motor + dados**. Nenhum componente sabe o que acontece no caso; todo
conteúdo entra por um objeto `CaseData`.

---

## 4. Adicionar um caso novo

```ts
// src/investigacao/cases/caso-01.ts
import type { CaseData } from "../types";

export const caso01: CaseData = {
  slug: "caso-01",
  title: "...",
  victim: { name: "...", avatarSeed: "..." },
  device: { passcode: "0000", carrier: "...", batteryPercent: 38, dateLabel: "..." },
  messages: [...], social: {...}, matches: {...},
  gallery: [...], locations: [...], bank: {...}, notes: [...],
};
```

```ts
// src/investigacao/cases/registry.ts
import { caso01 } from "./caso-01";

export const CASES: Record<string, CaseData> = {
  [casoDemo.slug]: casoDemo,
  [caso01.slug]: caso01,
};
```

Pronto: `/investigacao/caso-01` existe. Nenhum componente precisa ser tocado.

---

## 5. Notas de implementação

**Imagens.** Ainda não há arquivos reais. `MediaRef.seed` gera um placeholder
determinístico (gradiente + grão, dentro da paleta da marca). Quando as fotos
existirem, preencha `MediaRef.src` — a interface passa a usar o arquivo sem
nenhuma alteração de código. Mesma lógica para `Person.avatarSrc`.

**Áudio.** O player é simulado (barras + progresso). Não há arquivo tocando; quando
houver, o componente `AudioPlayer` é o único ponto a trocar.

**Evidências e cadeados.** Persistidos em `localStorage`, por caso, com `try/catch`
(funciona em modo privado, apenas sem salvar). Marcar evidência é opcional — é uma
ferramenta do investigador, nunca um requisito de progresso.

**Senhas de conteúdo.** São texto simples dentro do caso: é mecânica de jogo, não
segurança. Os placeholders atuais mostram a própria senha na dica; nos casos reais,
remova `hint` e coloque a senha dentro de outro aplicativo.

**Navegação.** Pilha interna (`DeviceProvider`), sem recarregar a página. Está
integrada ao botão voltar do navegador e do Android, e à tecla Esc no desktop. A URL
permanece `/investigacao/:slug` — a experiência se comporta como um aparelho único,
não como um conjunto de páginas.

**Isolamento visual.** Tudo vive sob `.inv-root`, inclusive a família tipográfica
(o site usa `IM Fell English` como sans global; dentro do aparelho isso quebraria a
ilusão de app real). Nenhum token global foi alterado.

**Desktop.** Aparelho centralizado de 392px sobre cena escura com grão, identificação
discreta do caso e botão "bloquear". Não é a versão mobile esticada.

**Acessibilidade e toque.** Alvos de toque de 44px+, `aria-label` nos controles de
ícone, foco preservado, e `prefers-reduced-motion` desliga as animações.

---

## 6. O que NÃO foi feito (de propósito)

Sem login, banco de dados, pagamento, IA, integrações reais (Instagram, WhatsApp,
Tinder, bancos, Google Maps), sem narrativa, sem pistas definitivas e sem sistema
complexo de progresso. O conteúdo de `caso-demo.ts` é só fiação de teste.
